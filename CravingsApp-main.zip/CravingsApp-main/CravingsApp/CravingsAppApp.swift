//
//  CravingsAppApp.swift
//  CravingsApp
//
//  Created by JZhang on 8/1/23.
//

import SwiftUI

@main
struct CravingsAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
